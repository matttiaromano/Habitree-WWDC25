import SwiftUI

struct InfoView: View {
    @Environment(\.dismiss) var dismiss
    @State private var animateLogo = false
    @State private var selectedTab = 0
    
    private var guideContent: some View {
        VStack(alignment: .leading, spacing: 20) {
            InfoRow(icon: "🌱", title: "Daily Habit", description: "Complete your habit every day to grow your plant")
            InfoRow(icon: "📈", title: "Progress", description: "Each 7 days streak upgrades your plant stage")
            InfoRow(icon: "🔁", title: "Consistency", description: "Maintain a streak for special achievements")
            InfoRow(icon: "➕", title: "New Habits", description: "Add unlimited habits with the + button")
        }
    }
    
    private var creditsContent: some View {
        VStack(spacing: 15) {
            Image(systemName: "person.crop.circle.fill")
                .font(.system(size: 60))
                .foregroundColor(.green)
            
            Text("Mattia Romano")
                .font(.title2.bold())
            
            Text("17 y/o Italian Developer\nPhotography & Code enthusiast")
                .multilineTextAlignment(.center)
                .font(.subheadline)
            
            HStack(spacing: 20) {
                Link(destination: URL(string: "https://github.com/matttiaromano")!) {
                    Image(systemName: "globe")
                        .font(.title)
                }
                
                Link(destination: URL(string: "mailto:mr@matttia.com")!) {
                    Image(systemName: "envelope.fill")
                        .font(.title)
                }
            }
            .foregroundColor(.green)
            .padding(.top, 10)
        }
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    // Animated Header
                    ZStack {
                        Circle()
                            .stroke(
                                LinearGradient(
                                    colors: [.teal, .green],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                ),
                                lineWidth: 4
                            )
                            .frame(width: 100, height: 100)
                            .scaleEffect(animateLogo ? 1.2 : 0.8)
                            .opacity(animateLogo ? 0.5 : 1)
                        
                        Image(systemName: "leaf.fill")
                            .font(.system(size: 50))
                            .foregroundColor(.green)
                            .scaleEffect(animateLogo ? 1.1 : 1)
                    }
                    .padding(.top, 20)
                    .onAppear {
                        withAnimation(.easeInOut(duration: 1.5).repeatForever()) {
                            animateLogo.toggle()
                        }
                    }
                    
                    // Tab Selector
                    Picker("", selection: $selectedTab) {
                        Text("Guide").tag(0)
                        Text("Credits").tag(1)
                    }
                    .pickerStyle(.segmented)
                    .padding(.horizontal)
                    
                    // Dynamic Content
                    Group {
                        switch selectedTab {
                        case 0: guideContent
                        case 1: creditsContent
                        default: EmptyView()
                        }
                    }
                    .transition(.opacity)
                }
                .padding()
            }
            .background(Color.black)
            .navigationTitle("About Habitree")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") { dismiss() }
                        .foregroundColor(.green)
                }
            }
        }
        .presentationDetents([.medium])
        .preferredColorScheme(.dark)
    }
}

struct InfoRow: View {
    let icon: String
    let title: String
    let description: String
    
    var body: some View {
        HStack(alignment: .top, spacing: 15) {
            Text(icon)
                .font(.title)
            
            VStack(alignment: .leading, spacing: 5) {
                Text(title)
                    .font(.headline)
                    .foregroundColor(.white)
                
                Text(description)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(red: 0.1, green: 0.1, blue: 0.1))
        .cornerRadius(12)
    }
}
