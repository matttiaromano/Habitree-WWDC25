import SwiftUI
import Foundation

class HabitStore: ObservableObject {
    @Published var habits: [Habit] = [] {
        didSet { save() }
    }
    
    @AppStorage("hasSeenInfo") var hasSeenInfo: Bool = false
    
    init() {
        loadHabits()
    }
    
    private func loadHabits() {
        if let data = UserDefaults.standard.data(forKey: "habits"),
           let decoded = try? JSONDecoder().decode([Habit].self, from: data) {
            habits = decoded
        }
    }
    
    func addHabit(name: String) {
        let newHabit = Habit(name: name)
        habits.append(newHabit)
    }
    
    func updateStreak(for habit: Habit) {
        guard let index = habits.firstIndex(where: { $0.id == habit.id }) else { return }
        habits[index].updateCompletion()
    }
    
    private func save() {
        if let encoded = try? JSONEncoder().encode(habits) {
            UserDefaults.standard.set(encoded, forKey: "habits")
        }
    }
    
    func deleteHabit(at offsets: IndexSet) {
        habits.remove(atOffsets: offsets)
    }
}

extension HabitStore {
    func updateHabitName(_ habit: Habit, newName: String) {
        guard let index = habits.firstIndex(where: { $0.id == habit.id }) else { return }
        habits[index].name = newName
    }
}
