import Foundation

struct Habit: Identifiable, Codable {
    let id: UUID
    var name: String
    private var _currentStreak: Int
    var lastCompletionDate: Date?
    var completionHistory: [Date] = []
    
    init(name: String) {
        self.id = UUID()
        self.name = name
        self._currentStreak = 0
    }
    
    var currentStreak: Int {
        get { _currentStreak }
        set { _currentStreak = max(newValue, 0) }
    }
    
    var completedTrees: Int {
        currentStreak / 7 // Modificato da 30 a 7
    }
    
    var isCompletedToday: Bool {
        guard let lastDate = lastCompletionDate else { return false }
        return Calendar.autoupdatingCurrent.isDateInToday(lastDate)
    }
    
    var currentStageSymbol: String {
        ["🌱", "🌿", "🪴", "🌳"][min(currentStreak / 7, 3)] // Basato su 7 giorni
    }
    
    mutating func updateCompletion() {
        let calendar = Calendar.autoupdatingCurrent
        let today = Date()
        
        if let lastDate = lastCompletionDate {
            if calendar.isDateInYesterday(lastDate) {
                currentStreak += 1
            } else if !calendar.isDateInToday(lastDate) {
                currentStreak = 1
            }
        } else {
            currentStreak = 1
        }
        
        lastCompletionDate = today
        completionHistory.append(today)
    }
}
