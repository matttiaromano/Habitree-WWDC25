import SwiftUI

struct HabitCardView: View {
    @Binding var habit: Habit
    @ObservedObject var store: HabitStore
    
    @State private var animationProgress: CGFloat = 0
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 25)
                .fill(Color.darkGray)
                .shadow(radius: 8)
            
            VStack(spacing: 25) {
                ZStack {
                    Circle()
                        .stroke(lineWidth: 10)
                        .opacity(0.3)
                        .foregroundColor(.gray)
                    
                    Circle()
                        .trim(from: 0, to: animationProgress)
                        .stroke(
                            LinearGradient(
                                colors: [.teal, .green],
                                startPoint: .leading,
                                endPoint: .trailing
                            ),
                            style: StrokeStyle(lineWidth: 10, lineCap: .round)
                        )
                        .rotationEffect(.degrees(-90))
                    
                    Text(habit.currentStageSymbol)
                        .font(.system(size: 50))
                        .foregroundColor(.green)
                }
                .frame(width: 150, height: 150)
                
                VStack(spacing: 10) {
                    Text(habit.name)
                        .font(.title2.bold())
                        .foregroundColor(.white)
                        .lineLimit(1)
                        .padding(.horizontal)
                    
                    Text("\(habit.currentStreak) Days Streak")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                    
                    Text("Completed Trees: \(habit.completedTrees)")
                        .font(.subheadline.bold())
                        .foregroundColor(.green)
                }
                
                Button {
                    store.updateStreak(for: habit)
                    withAnimation { updateProgress() }
                } label: {
                    Image(systemName: isCompletedToday ? "checkmark.circle.fill" : "circle")
                        .font(.system(size: 40))
                }
                .foregroundColor(isCompletedToday ? .green : .gray)
            }
            .padding(30)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 10)
        .onAppear { updateProgress() }
        .onChange(of: habit.currentStreak) { updateProgress() }
    }
    
    private var isCompletedToday: Bool {
        habit.isCompletedToday
    }
    
    private func updateProgress() {
        let progress = CGFloat(habit.currentStreak % 7) / 7 // Modificato da 30 a 7
        withAnimation(.easeInOut(duration: 0.8)) {
            animationProgress = progress
        }
    }
}
