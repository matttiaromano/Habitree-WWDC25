import SwiftUI

struct ContentView: View {
    @StateObject private var store = HabitStore()
    @State private var showingAdd = false
    @State private var showingInfo = false
    @State private var currentIndex = 0
    @State private var selectedHabit: Habit?
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Card Container
                ZStack {
                    Color.black
                    
                    if !store.habits.isEmpty {
                        TabView(selection: $currentIndex) {
                            ForEach(store.habits.indices, id: \.self) { index in
                                HabitCardView(habit: $store.habits[index], store: store)
                                    .tag(index)
                                    .padding(.top, 15)
                                    .contextMenu {
                                        Button {
                                            selectedHabit = store.habits[index]
                                        } label: {
                                            Label("Edit", systemImage: "pencil")
                                        }
                                        
                                        Button(role: .destructive) {
                                            store.deleteHabit(at: IndexSet(integer: index))
                                        } label: {
                                            Label("Delete", systemImage: "trash")
                                        }
                                    }
                            }
                        }
                        .tabViewStyle(.page(indexDisplayMode: .never))
                        .frame(height: UIScreen.main.bounds.height * 0.72)
                    } else {
                        Text("Add your first habit")
                            .font(.title3)
                            .foregroundColor(.gray)
                    }
                }
                
                // Status Bar
                VStack(spacing: 15) {
                    HStack(spacing: 8) {
                        ForEach(store.habits.indices, id: \.self) { index in
                            Button {
                                withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                    currentIndex = index
                                }
                            } label: {
                                Circle()
                                    .fill(currentIndex == index ? Color.green : Color.gray)
                                    .frame(width: 8, height: 8)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(12)
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .fill(.ultraThickMaterial)
                            .shadow(radius: 5)
                    )
                    .padding(.horizontal, 40)
                    
                    Button {
                        showingAdd = true
                    } label: {
                        Image(systemName: "plus.circle.fill")
                            .font(.system(size: 48))
                    }
                    .foregroundColor(.green)
                    .padding(.bottom, 20)
                }
                .padding(.top, 15)
            }
            .background(.black)
            .navigationTitle("Habitree")
            .navigationBarTitleDisplayMode(.large)
            .padding(.top, 10)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { showingInfo = true }) { // Azione corretta
                        Image(systemName: "info.circle")
                            .foregroundColor(.green)
                    }
                }
            }
            .sheet(isPresented: $showingInfo) {
                InfoView()
            }
            .sheet(isPresented: $showingAdd) {
                AddHabitView(store: store, onDismiss: {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                        currentIndex = store.habits.count - 1
                    }
                })
            }
            
            // Sheet per modificare le abitudini esistenti
            .sheet(item: $selectedHabit) { habit in
                AddHabitView(
                    store: store,
                    habitToEdit: habit, 
                    onDismiss: {
                        if let index = store.habits.firstIndex(where: { $0.id == habit.id }) {
                            currentIndex = index
                        }
                    }
                )
            }
        }
        .preferredColorScheme(.dark) // Forza dark mode
    }
}
