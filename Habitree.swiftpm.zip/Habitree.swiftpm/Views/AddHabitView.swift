import SwiftUI

struct AddHabitView: View {
    @ObservedObject var store: HabitStore
    var onDismiss: () -> Void
    @Environment(\.dismiss) var dismiss
    @State private var name = ""
    var habitToEdit: Habit? = nil // Aggiungi valore default
    
    init(store: HabitStore, habitToEdit: Habit? = nil, onDismiss: @escaping () -> Void) { // Nuovo init
        self.store = store
        self.habitToEdit = habitToEdit
        self.onDismiss = onDismiss
        
        if let habit = habitToEdit {
            _name = State(initialValue: habit.name)
        }
    } 
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 30) {
                TextField("Habit name", text: $name)
                    .padding()
                    .background(
                        
                RoundedRectangle(cornerRadius: 15)
                            .fill(Color.darkGray)
                    )
                    .padding(.horizontal)
                
                Button(habitToEdit == nil ? "Add Habit" : "Save Changes") {
                    if let habit = habitToEdit {
                        store.updateHabitName(habit, newName: name)
                    } else {
                        store.addHabit(name: name)
                    }
                    dismiss()
                    onDismiss()
                }
                .buttonStyle(.borderedProminent)
                .tint(.green)
                .disabled(name.isEmpty)
            }
            .padding()
            .navigationTitle("New Habit")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
            .background(.black)
        }
        .preferredColorScheme(.dark)
    }
}

// Estensione per colore personalizzato
extension Color {
    static let darkGray = Color(red: 0.1, green: 0.1, blue: 0.1)
}
