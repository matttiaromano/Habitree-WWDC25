import SwiftUI

@main
struct RootedApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(HabitStore())
        }
    }
}

